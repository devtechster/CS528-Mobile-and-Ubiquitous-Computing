Main file: CrimeDetailFragment

The whole UI interface has been designed. There's a textview at the bottom that doesn't have any text and it's going to print out how many faces detection there are in the image.(May only be used in facedetection).

I finished the function of storing the photo in a different imageview after taking it. There is also the feature that checkboxes can only be selected once, and this has been commented in the file of CrimeDetailFragment.

Suggestion for next step:
At first, we need to click the checkbox we want to select. I annotated four checkboxes in the code, 1, 2, 3, and 4. You can see in the xml file which function they correspond to.

You can add your code to the CrimeDetailFragment file.
