package com.example.project1screen2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.project1screen2.ui.theme.Project1Screen2Theme

class MainActivity : AppCompatActivity() {

    private var clickCount = 0

    fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val image1 = findViewById<ImageView>(R.id.image1)
        val image2 = findViewById<ImageView>(R.id.image2)
        val image3 = findViewById<ImageView>(R.id.image3)

        val image1Count = findViewById<TextView>(R.id.image1)
        val image2Count = findViewById<TextView>(R.id.image2)
        val image3Count = findViewById<TextView>(R.id.image3)

        button.setOnClickListener {
            clickCount++
            image1Count = clickCount.toString()

            // Change the image in the ImageView based on the click count
            if (clickCount % 2 == 0) {
                imageView.setImageResource(R.drawable.even_image)
            } else {
                imageView.setImageResource(R.drawable.odd_image)
            }
        }
    }
}





